package com.example.tictactoegame;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ScoreActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_activitiy);
        try {
            SQLiteDatabase sqLiteDatabase = this.openOrCreateDatabase("TicTacToeGame", MODE_PRIVATE, null);
            Cursor c = sqLiteDatabase.rawQuery("Select * from ScoreTable", null);
            int playerOneNameIndex = c.getColumnIndex("playerOneName");
            int playerTwoNameIndex = c.getColumnIndex("playerTwoName");
            c.moveToFirst();

            ListView listView = findViewById(R.id.listViewNames);
            ArrayList<String> players = new ArrayList<String>();
            while (!c.isAfterLast()) {
//                Toast.makeText(this, c.getString(playerOneNameIndex), Toast.LENGTH_SHORT).show();
                players.add(c.getString(playerOneNameIndex));
                players.add(c.getString(playerTwoNameIndex));
                c.moveToNext();
            }
            ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1);
            listView.setAdapter(arrayAdapter);
        } catch (Exception ex) {
            ex.printStackTrace();

        }


    }
}